package bank;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * H2 데이터베이스 연결 테스트.
 * lib/h2-*.jar 를 classpath에 넣고 실행하면 "접속 성공!"이 출력된다.
 */
public class DBTest {
    static final String URL = "jdbc:h2:./bankdb";
    static final String USER = "sa";
    static final String PASSWORD = "";

    static {
        try {
            // JDBC 드라이버 로딩 (JDBC 4부터는 생략 가능하지만, 명시적으로 확인)
            Class.forName("org.h2.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            System.out.println(conn + " 접속 성공!");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
