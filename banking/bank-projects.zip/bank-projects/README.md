# 🏦 은행 계좌 관리 시스템 — 완성 프로젝트

같은 은행 로직을 두 가지 방식으로 구현한 바로 실행 가능한 완성본입니다.

| 폴더 | 버전 | 실행 |
|------|------|------|
| `1-console` | 순수 Java 콘솔 (메모리) | `javac` 후 `java bank.BankApp` |
| `1b-console-h2` | 순수 Java 콘솔 + **H2 DB** (JDBC) | h2.jar 넣고 `javac`/`java` (README 참고) |
| `2-spring-boot` | Spring Boot + JPA + **H2** REST API | `mvn spring-boot:run` |

## 1-console (순수 Java)
```bash
cd 1-console
javac -d out src/bank/*.java
java -cp out bank.BankApp
```
프레임워크 없이 콘솔 메뉴로 동작. 샘플 계좌 110-0001(홍길동)·110-0002(김철수) 자동 생성.

## 2-spring-boot (Spring Boot + H2)
```bash
cd 2-spring-boot
mvn spring-boot:run
```
설치 없이 바로 실행(H2 메모리 DB). 서버: http://localhost:8080/accounts
자세한 내용은 `2-spring-boot/README.md` 참고.

## 핵심 포인트
계좌·입금·출금·이체 같은 **핵심 로직은 두 버전이 거의 동일**합니다.
달라지는 것은 "요청을 어떻게 받고(메뉴 vs REST), 데이터를 어디에 저장하느냐(메모리 vs DB)" 뿐입니다.
