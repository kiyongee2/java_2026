<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>은행 계좌 관리 (JSP + Servlet)</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
<c:set var="ctx" value="${pageContext.request.contextPath}"/>
<div class="wrap">
    <h1>🏦 은행 계좌 관리 <small>JSP + Servlet + H2</small></h1>

    <%-- 결과/오류 메시지 (서블릿이 request에 담아 forward) --%>
    <c:if test="${not empty message}"><div class="msg ok">${message}</div></c:if>
    <c:if test="${not empty error}"><div class="msg err">${error}</div></c:if>

    <%-- 계좌 목록 : JSTL c:forEach 로 반복 --%>
    <h2>계좌 목록</h2>
    <table>
        <thead>
        <tr><th>계좌번호</th><th>예금주</th><th class="r">잔액</th><th class="c">관리</th></tr>
        </thead>
        <tbody>
        <c:forEach var="a" items="${accounts}">
            <tr>
                <td>${a.accountNumber}</td>
                <td>${a.owner}</td>
                <td class="r"><fmt:formatNumber value="${a.balance}" type="number"/>원</td>
                <td class="c">
                    <form action="${ctx}/accounts" method="post"
                          onsubmit="return confirm('정말 해지하시겠습니까?');">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="no" value="${a.accountNumber}">
                        <button class="danger">해지</button>
                    </form>
                </td>
            </tr>
        </c:forEach>
        <c:if test="${empty accounts}">
            <tr><td colspan="4" class="empty">등록된 계좌가 없습니다.</td></tr>
        </c:if>
        </tbody>
    </table>

    <%-- 기능 폼들 : 숨은 action 파라미터로 서블릿에서 기능 구분 --%>
    <div class="cards">
        <div class="card">
            <h3>➕ 계좌 개설</h3>
            <form action="${ctx}/accounts" method="post">
                <input type="hidden" name="action" value="create">
                <label>예금주 <input name="owner" required></label>
                <label>초기 입금액 <input name="initialBalance" type="number" value="0" min="0"></label>
                <button>개설</button>
            </form>
        </div>

        <div class="card">
            <h3>💰 입금</h3>
            <form action="${ctx}/accounts" method="post">
                <input type="hidden" name="action" value="deposit">
                <label>계좌번호 <input name="no" placeholder="110-0001" required></label>
                <label>입금액 <input name="amount" type="number" value="10000" min="1" required></label>
                <button>입금</button>
            </form>
        </div>

        <div class="card">
            <h3>💸 출금</h3>
            <form action="${ctx}/accounts" method="post">
                <input type="hidden" name="action" value="withdraw">
                <label>계좌번호 <input name="no" placeholder="110-0001" required></label>
                <label>출금액 <input name="amount" type="number" value="10000" min="1" required></label>
                <button>출금</button>
            </form>
        </div>

        <div class="card">
            <h3>🔄 이체</h3>
            <form action="${ctx}/accounts" method="post">
                <input type="hidden" name="action" value="transfer">
                <label>보내는 계좌 <input name="from" placeholder="110-0001" required></label>
                <label>받는 계좌 <input name="to" placeholder="110-0002" required></label>
                <label>이체 금액 <input name="amount" type="number" value="10000" min="1" required></label>
                <button>이체</button>
            </form>
        </div>
    </div>

    <p class="foot">Model 2 MVC — Servlet(Controller) + JSP(View) + DAO(Model) · DB: H2</p>
</div>
</body>
</html>
