# 은행 계좌 관리 (JSP + Servlet + H2)

Spring 이전의 전통적인 **Model 2 MVC** 웹앱입니다.
`Servlet`(Controller) + `JSP`(View) + `DAO`(Model) + `H2`(DB) 구조로, 순수 Jakarta EE로 만들었습니다.

> ⚙️ 대상: **Tomcat 10 이상 (Jakarta EE 10, `jakarta.servlet.*`)**, Java 21

## 구조 (Model 2 MVC)
```
3-jsp-servlet/
├─ pom.xml                          (packaging: war)
└─ src/main/
   ├─ java/com/example/bank/
   │  ├─ model/Account.java          Model — 데이터
   │  ├─ dao/Db.java                 DB 연결 + 테이블 생성
   │  ├─ dao/AccountDao.java         Model — JDBC(SQL)
   │  ├─ service/BankService.java    업무 로직 + 이체 트랜잭션
   │  ├─ controller/AccountServlet.java   Controller — @WebServlet("/accounts")
   │  └─ listener/DbInitListener.java     시작 시 테이블·샘플 생성
   └─ webapp/
      ├─ index.jsp                   /accounts 로 리다이렉트
      ├─ css/style.css
      └─ WEB-INF/
         ├─ web.xml
         └─ views/accounts.jsp       View — 화면(JSTL)
```

## 동작 흐름 (Model 2)
1. 브라우저 요청 → **Servlet**(Controller)이 받음
2. Servlet → **Service/DAO**(Model)로 DB 처리
3. 결과를 `request`에 담아 **JSP**(View)로 `forward` → 화면 생성
4. 폼 전송(POST)은 처리 후 목록으로 `redirect` (PRG 패턴, flash 메시지는 session 이용)

## 실행 방법 — IntelliJ + Tomcat 10

1. **Tomcat 10.1** 다운로드: https://tomcat.apache.org/download-10.cgi (zip 풀어두기)
2. IntelliJ에서 이 폴더를 **Maven 프로젝트**로 열기 (pom.xml 인식)
3. `Run → Edit Configurations → + → Tomcat Server → Local`
   - `Application server`에서 위 Tomcat 10 폴더 지정
   - `Deployment` 탭 → `+` → **Artifact** → `bank-jsp-servlet:war exploded` 추가
   - `Application context`를 `/bank` 로 설정
4. ▶ 실행 → 브라우저에서 **http://localhost:8080/bank/** 접속
   - 샘플 계좌 110-0001(홍길동), 110-0002(김철수)가 자동 생성됨

> 💡 IntelliJ Community 버전은 Tomcat 연동이 없습니다. **Ultimate** 또는 Eclipse(+Tomcat)를 사용하세요.
> Eclipse: `Dynamic Web Project`로 임포트하거나, WAR로 빌드해 톰캣 `webapps/`에 넣어도 됩니다.

## H2 데이터
- 메모리 DB(`jdbc:h2:mem:bankdb`)라 설치가 필요 없고, **서버를 끄면 초기화**됩니다.
- 파일로 저장하려면 `dao/Db.java`의 URL을 `jdbc:h2:~/bankdb`(사용자 홈)로 바꾸세요.

## 다른 버전과의 관계
| 버전 | 구조 | 화면 |
|------|------|------|
| 2-spring-boot | Spring MVC + REST | 없음(JSON) |
| 2b-spring-thymeleaf | Spring MVC + Thymeleaf | Thymeleaf |
| **3-jsp-servlet** | **순수 Servlet/JSP (Model 2)** | **JSP** |

Spring이 자동으로 해주던 것(요청 매핑·DI·뷰 렌더링)을 **직접** 하는 게 이 버전입니다.
그래서 Spring이 무엇을 대신해 주는지 명확히 이해할 수 있습니다.
